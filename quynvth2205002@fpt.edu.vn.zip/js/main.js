
    var n = 11;
    var sum = 0;
    do
    {
        sum = sum + n;
        n = n + 1;
    }while(n<=10)
    alert('Sum = ' + sum);
